NEXORA SOULS — PROJETO PARA GITHUB

ESTRUTURA
- pom.xml: dependência Paper API e configuração Maven/Java 21.
- src/main/java/.../NexoraSouls.java: código principal.
- src/main/resources/plugin.yml: identificação e comando /almas.
- src/main/resources/config.yml: mensagens, recompensas e percentual PvP.
- .github/workflows/build.yml: compilação automática pelo GitHub Actions.

COMO ENVIAR
Extraia este ZIP e envie TODO o conteúdo que está dentro da pasta NexoraSouls
para a raiz do repositório GitHub. Não envie apenas o ZIP.

COMO BAIXAR O JAR
Depois de enviar os arquivos, abra a aba Actions no GitHub.
Aguarde a execução "Compilar NexoraSouls" terminar com sucesso.
Abra a execução e baixe o artefato NexoraSouls-JAR.

IMPORTANTE
Esta versão implementa:
- /almas para consultar o saldo.
- Transferência de 50% das almas da vítima ao jogador que a derrotou.
- Recompensas por matar mobs configurados em config.yml.
- Salvamento dos saldos em data.yml.

A loja está apenas configurada no config.yml; o sistema de compra ainda não foi
implementado. Comandos administrativos e proteção anti-farm também não estão
incluídos nesta versão.

O HTML do site Minecraft Origins é um projeto separado e não deve ser colocado
dentro deste plugin Paper.
